$(function() {
    var store = new Persist.Store('CareLine');

});